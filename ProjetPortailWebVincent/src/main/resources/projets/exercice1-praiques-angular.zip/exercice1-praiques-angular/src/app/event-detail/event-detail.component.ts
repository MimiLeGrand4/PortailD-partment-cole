import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-event-detail',
  templateUrl: './event-detail.component.html',
  styleUrls: ['./event-detail.component.css']
})
export class EventDetailComponent  {
  evenement = {
    nom: 'Cours Angular ',
    date: '27/05/2022',
    heure: '8am',
    location: {address: 'College de Rosemont, 6400 16e Avenue, Montréal, QC H1X 2S9', ville: 'Montreal', pays: 'Canada'}
  };

}




