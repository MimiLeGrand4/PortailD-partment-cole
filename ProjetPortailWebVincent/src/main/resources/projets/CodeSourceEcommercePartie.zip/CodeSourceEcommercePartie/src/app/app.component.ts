import { Component } from '@angular/core';
//Le décorateur @Component indique à Angular que la classe
// AppComponent est un composant et que ses propriétés
//configurent la manière dont le composant est appliqué
@Component({
  /*La propriété selector indique à Angular comment 
  appliquer le composant dans le document HTML, 
  et la propriété template définit le contenu HTML que 
  le composant affichera. Les composants peuvent définir des modèles en ligne,
   comme celui-ci, ou ils utilisent des fichiers HTML externes, 
  ce qui peut faciliter la gestion de contenu complexe
  
  */
  selector: 'app-root',
  // templateUrl: './app.component.html',
  /*
  template: `<div class="bg-success p-2 text-center text-white">
    Bienvenue ChezBio
  </div>`,
  */
  template: '<app-magasin></app-magasin>',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'ChezBioV1';
}
