export class Produit {
  constructor(
    public id?: number,
    public nom?: string,
    public prix?: number,
    public description?: string,
    public urlPhoto?: string,
    public derniere_maj?: Date,
    public categorie?: string
  ) {}
}
