import { Injectable } from '@angular/core';
import { Produit } from './produit.model';
import { StaticDataSource } from './static.datasource';

@Injectable()
export class ProduitRepository {
  private produits: Produit[] = [];
  private categories: string[] = [];
  constructor(private dataSource: StaticDataSource) {
    dataSource.getProduits().subscribe((data) => {
      this.produits = data;
      this.categories = data
        .map((p) => p.categorie)
        .filter((c, index, array) => array.indexOf(c) == index)
        .sort();
    });
  }
   /*
  La map transforme les éléments d'un tableau 
  et renvoie un nouveau tableau avec les valeurs transformées.
  Exemple :

  let numbers = [1, 2, 3, 4]
  let squares = numbers.map(num => num * num);
> squares
= [ 1, 4, 9, 16 ]

Lorsque la methode filter termine l'itération, il renvoie le tableau des éléments sélectionnés
 : les éléments pour lesquels le rappel a renvoyé une valeur vraie.
 Dans notre exemple ci-dessous, la méthode filter sélectionne 
 tous les éléments avec une valeur supérieure à 4.
> let numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 2]
> numbers.filter(num => num > 4)
= [ 5, 6, 7, 8, 9, 10 ]


La méthode indexof retourne le premier index de l'élément dans le tableau 
ou -1 si la valeur n'est pas trouvée.
var tableau = [2, 9, 9];
tableau.indexOf(2);     // 0
tableau.indexOf(7);     // -1

La méthode sort() trie les éléments d'un tableau, dans ce même tableau, et renvoie le tableau
const months = ['March', 'Jan', 'Feb', 'Dec'];
months.sort();
console.log(months);
// expected output: Array ["Dec", "Feb", "Jan", "March"]
  */
  getProduits(categorie: string = null): Produit[] {
    return this.produits.filter(
      (p) => categorie == null || categorie == p.categorie
    );
  }
  getProduit(id: number): Produit {
    return this.produits.find((p) => p.id == id);
  }
  getCategories(): string[] {
    return this.categories;
  }
}
