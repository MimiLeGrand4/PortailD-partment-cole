import { Component, OnInit } from '@angular/core';
import { Produit } from 'src/app/models/produit.model';
import { ProduitRepository } from 'src/app/models/produit.repository';

@Component({
  selector: 'app-magasin',
  templateUrl: './magasin.component.html',
  styleUrls: ['./magasin.component.css'],
})
export class MagasinComponent {
  public categorieSelectionnee = null;
  public produitsParPage = 4;
  public pageSectionnee = 1;
  constructor(private repository: ProduitRepository) {}
  get produits(): Produit[] {
    let pageIndex = (this.pageSectionnee - 1) * this.produitsParPage;
    return this.repository
      .getProduits(this.categorieSelectionnee)
      .slice(pageIndex, pageIndex + this.produitsParPage);
      //La méthode slice() renvoie un objet tableau, 
      //contenant une copie superficielle (shallow copy) 
      //d'une portion du tableau d'origine, la portion 
      //est définie par un indice de début et un indice de fin
      //const animals = ['ant', 'bison', 'camel', 'duck', 'elephant'];
       //console.log(animals.slice(2));
   // expected output: Array ["camel", "duck", "elephant"]
   //console.log(animals.slice(2, 4));
   //// expected output: Array ["camel", "duck"]
  }
  get categories(): string[] {
    return this.repository.getCategories();
  }
  changerCategorie(nouvelleCategorie?: string) {
    this.categorieSelectionnee = nouvelleCategorie;
  }
  changerPage(nouvellePage: number) {
    this.pageSectionnee = nouvellePage;
  }
  changerPageTaille(nouvelleTaille: number) {
    this.produitsParPage = Number(nouvelleTaille);
    this.changerPage(1);
  }

  get pageNumbers(): number[] {
    return Array(
      Math.ceil(
        this.repository.getProduits(this.categorieSelectionnee).length /
          this.produitsParPage
      )
    )
      .fill(0)
      .map((x, i) => i + 1);
      //La méthode fill() remplit tous les éléments 
      //d'un tableau entre deux index avec une valeur statique.
  }

  get compterPage(): number {
    return Math.ceil(
      this.repository.getProduits(this.categorieSelectionnee).length /
        this.produitsParPage
    );
  }
}
