import { Injectable } from '@angular/core';

import { Observable, from } from 'rxjs';
import { Produit } from './produit.model';

@Injectable()
export class StaticDataSource {
  date: Date = new Date();

  private listeproduits: Produit[] = [
    new Produit(
      1,
      'GRUYERE',
      12,
      'plaquette',
      '/assets/images/produits/GRUYERE.png',
      this.date,
      'FROMAGES'
    ),
    new Produit(2, 'PIZZA', 16, 'unite', '/assets/images/produits/PIZZA.png', this.date, 'PAINS'),
    new Produit(3, 'RADIS', 17, 'kg', '/assets/images/produits/RADIS.png', this.date, 'LEGUMES'),
    new Produit(4, 'POULET', 10, 'kg', '/assets/images/produits/POULET.png', this.date, 'VIANDES'),
  ];

  getProduits(): Observable<Produit[]> {
    return from([this.listeproduits]);
  }
}
