import { NgModule } from '@angular/core';
import { ProduitRepository } from './produit.repository';

import { StaticDataSource } from './static.datasource';

@NgModule({
  providers: [ProduitRepository, StaticDataSource],
})
export class ModelModule {}
