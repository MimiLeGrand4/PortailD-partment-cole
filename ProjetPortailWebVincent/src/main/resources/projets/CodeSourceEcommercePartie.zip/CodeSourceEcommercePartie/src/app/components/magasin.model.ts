import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { ModelModule } from '../models/model.module';
import { CompterDirective } from './compter.directive';
import { MagasinComponent } from './magasin.component';

@NgModule({
  imports: [ModelModule, BrowserModule, FormsModule],
  declarations: [MagasinComponent, CompterDirective],
  exports: [MagasinComponent],
})
export class MagasinModule {}
