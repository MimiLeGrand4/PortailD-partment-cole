import {
  Directive,
  ViewContainerRef,
  TemplateRef,
  Input,
  Attribute,
  SimpleChanges,
} from '@angular/core';
//Pour créer une directive personnalisée, 
//nous devons remplacer @Component
//décorateur 
//par le décorateur @Directive
@Directive({
  selector: '[counterOf]',
})
export class CompterDirective {
  constructor(
    //ViewContainerRef représente un conteneur dans lequel une ou
    // plusieurs vues peuvent être attachées à un composant.
    private container: ViewContainerRef,
    //TemplateRef représente un template incorporé qui peut 
    //être utilisé
    // pour instancier des vues incorporées.
    private template: TemplateRef<Object>
  ) {}

  @Input('counterOf')
  counter: number;
//La méthode ngOnChanges()utilise SimpleChanges
//comme argument qui donne les valeurs nouvelles et précédentes
// des valeurs d'entrée après les modifications
  ngOnChanges(changes: SimpleChanges) {
    this.container.clear();
    for (let i = 0; i < this.counter; i++) {
      //on utilise la méthode createEmbeddedView
      // pour instancier une vue incorporée
      this.container.createEmbeddedView(
        this.template,
        new CompterDirectiveContext(i + 1)
      );
    }
  }
}

class CompterDirectiveContext {
  //L'utilisation de  $implicitd ans 
  //l'objet de contexte définira sa valeur par défaut.
  //J'ai utilisé $implicit pour transmettre la valeur
  // à template,
  // en créant dynamiquement les numeros de pages
  constructor(public $implicit: any) {}
}
