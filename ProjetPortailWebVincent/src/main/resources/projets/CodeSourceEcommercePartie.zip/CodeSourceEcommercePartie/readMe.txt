Pour tester l'application
Créer un projet Angular
Installer Bootstrap
npm install bootstrap@4.1.1
copier et coller repertoire src dans le projet.
Mettez la valeur  "strict": false, dans le fichier tsconfig.json
lancer l'application.

